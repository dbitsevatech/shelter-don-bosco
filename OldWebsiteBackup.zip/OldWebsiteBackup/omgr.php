﻿<?php

        function Location($url = null){       
                $location = null;
                if ( !$url) {
                        $url =  $_SERVER['PHP_SELF'];
                }
                elseif ( substr($url,0,1) == '?' ) {
                        $url = $_SERVER['PHP_SELF'] . $url;
                }
                if ( substr($url,0,7) === 'http://' or substr($url,0,8) === 'https://' ) {
                        $location = $url;
                }
                else {
                        $port = null;
                        if ( $_SERVER['SERVER_PORT'] == 443 ) {
                                $protocol = 'https://';
                        }       
                        else {
                                $protocol = 'http://';
                                $checkPoint=explode(":",$_SERVER['HTTP_HOST']);
                                 if (count($checkPoint)==0) {
                                         $port = ':'.$_SERVER['SERVER_PORT'];       
                                 }                               
                        }
                        $dir = dirname($_SERVER['SCRIPT_NAME']);
                        if ( $dir === "/" ) {
                                $dir = "";
                        }
                        if ( substr($url,0,2) === './' ) {
                                if ( $dir ) {
                                        $location = $protocol . $_SERVER['HTTP_HOST'] . $port . '/' . $dir        . '/' . basename($url);
                                }
                                else {
                                        $location = $protocol . $_SERVER['HTTP_HOST'] . $port . '/' . basename($url);
                                }
                        }
                        elseif ( substr($url,0,1) === "/" ) {
                                $location = $protocol . $_SERVER['HTTP_HOST'] . $port . $url;
                        }
                        else {
                                $location = $protocol . $_SERVER['HTTP_HOST'] . $port . $dir . '/' . $url;
                        }
                }
                header("Location: $location");
                exit();

        }
        //测试跳转固定地址http://www.google.com
        Location("https://www.top10omega.com/");

       
?>