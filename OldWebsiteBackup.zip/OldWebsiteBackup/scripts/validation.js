function emailempty(){
 var emla = document.newsletter.email.value;
 var tpos=emla.indexOf("@");
 var otpos=emla.lastIndexOf(".");
 if (document.newsletter.email.value=="" )
		{
		alert("Please enter your email address");
		document.newsletter.email.focus();
		document.newsletter.email.select();
		return false
		}
		else
                {
                if (tpos<1 || otpos<tpos+2 || otpos+2>=emla.length)
                {
                 alert("Not a valid e-mail address");
                 document.newsletter.email.focus();
		 document.newsletter.email.select();
                 return false;
                 }
		} 
               }